// This is an improved version of the community_review_launch_screen.dart file focusing on better error handling

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:dreamflow/models/community_model.dart';
import 'package:dreamflow/services/community_service.dart';
import 'package:dreamflow/widgets/common_widgets.dart';
import 'package:dreamflow/widgets/error_notification.dart';
import 'package:dreamflow/utils/error_messages.dart';
import 'package:dreamflow/theme.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:dreamflow/widgets/responsive_layout.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dreamflow/screens/community_dashboard_screen.dart';
import 'package:uuid/uuid.dart';

class CommunityReviewLaunchScreenImproved extends StatefulWidget {
  final String userId;
  final Community community;

  const CommunityReviewLaunchScreenImproved({
    Key? key,
    required this.userId,
    required this.community,
  }) : super(key: key);

  @override
  State<CommunityReviewLaunchScreenImproved> createState() => _CommunityReviewLaunchScreenImprovedState();
}

class _CommunityReviewLaunchScreenImprovedState extends State<CommunityReviewLaunchScreenImproved> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  bool _isPublishing = false;
  bool _showConfetti = false;
  String? _errorMessage;
  bool _isErrorVisible = false;
  bool _isCommunityFound = true; // Default to true to avoid flickering

  @override
  void initState() {
    super.initState();
    
    // Set up animations
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0.0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    
    // Start animations
    _animationController.forward();
    
    // Check if the community exists
    _verifyCommunityExists();
  }

  // Verify the community actually exists in the database
  Future<void> _verifyCommunityExists() async {
    try {
      final community = await CommunityService.getCommunityById(widget.community.id);
      if (mounted) {
        setState(() {
          _isCommunityFound = community != null;
        });
      }
      
      if (community == null) {
        // Display appropriate error if community not found
        setState(() {
          _errorMessage = 'We couldn\'t find this community. It may have been deleted or there might be a temporary issue.';
          _isErrorVisible = true;
        });
      }
    } catch (e) {
      // Handle verification error
      if (mounted) {
        setState(() {
          _isCommunityFound = false;
          _errorMessage = 'There was an issue loading this community\'s details. Please try again.';
          _isErrorVisible = true;
        });
      }
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _launchCommunity() async {
    // Prevent double-clicks
    if (_isPublishing) return;
    
    // First hide any previous error
    setState(() {
      _isPublishing = true;
      _errorMessage = null;
      _isErrorVisible = false;
    });
    
    try {
      print('Starting community publishing process for ID: ${widget.community.id}');
      
      // First, make a more reliable check to ensure the community exists
      final communityCheck = await CommunityService.getCommunityById(widget.community.id);
      
      if (communityCheck == null) {
        throw Exception('Community not found in database before publishing attempt');
      }
      
      // Attempt to publish the community
      final publishedCommunity = await CommunityService.publishCommunity(widget.community.id);
      
      // Handle case where publishCommunity returns null
      if (publishedCommunity == null) {
        throw Exception('Failed to publish community: No community returned after publish operation');
      }
      
      print('Community published successfully with ID: ${publishedCommunity.id}');
      
      // Create a membership for the creator (more reliable implementation)
      final creatorMembership = await CommunityService.joinCommunity(
        userId: widget.userId, 
        communityId: widget.community.id,
        tierId: publishedCommunity.tiers.isNotEmpty ? publishedCommunity.tiers.last.id : '',
      );
      
      if (creatorMembership == null) {
        // We can still proceed even if membership creation fails
        print('Warning: Creator membership could not be created, but community was published');
      }
      
      // Show success state with confetti animation
      if (mounted) {
        setState(() {
          _showConfetti = true;
          _isPublishing = false;
        });
        
        // Navigate to the community dashboard after a short delay
        Future.delayed(const Duration(seconds: 2), () {
          if (mounted) {
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                builder: (context) => CommunityDashboardScreen(
                  community: publishedCommunity,
                  userId: widget.userId,
                  membership: creatorMembership ?? CommunityMembership(
                    id: const Uuid().v4(),
                    userId: widget.userId,
                    communityId: publishedCommunity.id,
                    tierId: publishedCommunity.tiers.isNotEmpty ? publishedCommunity.tiers.last.id : '',
                    joinedAt: DateTime.now(),
                  ),
                ),
              ),
              (route) => false,
            );
          }
        });
      }
    } catch (e) {
      // Handle publishing errors with user-friendly messages
      String userFriendlyMessage = 'We encountered an issue while publishing your community.';
      
      // Determine the specific type of error if possible
      if (e.toString().contains('permission-denied')) {
        userFriendlyMessage = 'You may not have permission to publish this community. This could be due to subscription status or network issues.';
      } else if (e.toString().contains('not-found')) {
        userFriendlyMessage = 'This community could not be found. It may have been deleted.';
      } else if (e.toString().contains('network')) {
        userFriendlyMessage = 'We\'re having trouble connecting to our servers. Please check your internet connection and try again.';
      }
      
      // Update UI with the error
      if (mounted) {
        setState(() {
          _isPublishing = false;
          _errorMessage = userFriendlyMessage;
          _isErrorVisible = true;
        });
        
        // Log the detailed error for debugging
        print('Error publishing community: $e');
      }
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Review & Launch'),
        elevation: 0,
        backgroundColor: Theme.of(context).colorScheme.surface,
        foregroundColor: Theme.of(context).colorScheme.onSurface,
      ),
      body: _isCommunityFound
          ? FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(16.r),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Information banner (only show when no error is present)
                      if (!_isErrorVisible)
                        Container(
                          padding: EdgeInsets.all(16.r),
                          margin: EdgeInsets.only(bottom: 16.r),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8.r),
                            border: Border.all(color: Theme.of(context).colorScheme.primary.withOpacity(0.3)),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.info_outline,
                                color: Theme.of(context).colorScheme.primary,
                                size: 24.r,
                              ),
                              SizedBox(width: 12.w),
                              Expanded(
                                child: Text(
                                  'Your community will be created but not yet published. You can start customizing it and publish when you\'re ready.',
                                  style: AppTypography.bodyText(context),
                                ),
                              ),
                            ],
                          ),
                        ),
                      
                      // Error banner (only show when there is an error)
                      if (_isErrorVisible && _errorMessage != null)
                        ErrorNotification.banner(
                          message: _errorMessage!,
                          context: context,
                          type: NotificationType.error,
                          onDismiss: () {
                            setState(() {
                              _isErrorVisible = false;
                              _errorMessage = null;
                            });
                          },
                        ),
                      
                      // Rest of the UI...
                      // (Community preview and other sections would go here)
                      
                      // Action buttons at the bottom
                      SizedBox(height: 24.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextButton(
                            onPressed: _isPublishing ? null : () {
                              Navigator.of(context).pop();
                            },
                            child: Text('Go Back'),
                          ),
                          ElevatedButton(
                            onPressed: _isPublishing ? null : _launchCommunity,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Theme.of(context).colorScheme.primary,
                              foregroundColor: Theme.of(context).colorScheme.onPrimary,
                              padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 12.h),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.r)),
                            ),
                            child: _isPublishing
                                ? Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SizedBox(
                                        width: 20.r,
                                        height: 20.r,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2.r,
                                          valueColor: AlwaysStoppedAnimation<Color>(
                                            Theme.of(context).colorScheme.onPrimary,
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 8.w),
                                      Text('Publishing...'),
                                    ],
                                  )
                                : Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.rocket_launch, size: 20.r),
                                      SizedBox(width: 8.w),
                                      Text('Launch Community'),
                                    ],
                                  ),
                          ),
                        ],
                      ),
                      SizedBox(height: 16.h),
                    ],
                  ),
                ),
              ),
            )
          : Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.error_outline,
                    size: 64.r,
                    color: Theme.of(context).colorScheme.error,
                  ),
                  SizedBox(height: 16.h),
                  Text(
                    'Community Not Found',
                    style: AppTypography.titleLarge(context)?.copyWith(
                      color: Theme.of(context).colorScheme.error,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 32.w),
                    child: Text(
                      'We couldn\'t find this community. It may have been deleted or there might be a temporary issue.',
                      textAlign: TextAlign.center,
                      style: AppTypography.bodyText(context),
                    ),
                  ),
                  SizedBox(height: 24.h),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text('Go Back'),
                  ),
                ],
              ),
            ),
    );
  }
}