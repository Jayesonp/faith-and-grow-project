import 'package:flutter/material.dart';
import 'dart:typed_data';
import 'package:dreamflow/models/community_model.dart';
import 'package:dreamflow/services/community_service.dart';
import 'package:dreamflow/widgets/common_widgets.dart';
import 'package:dreamflow/widgets/error_notification.dart';
import 'package:dreamflow/utils/error_messages.dart';
import 'package:dreamflow/theme.dart';
import 'package:dreamflow/image_upload.dart';
import 'package:dreamflow/services/storage_service.dart';
import 'package:dreamflow/screens/community_dashboard_screen.dart';
import 'package:dreamflow/screens/community_review_launch_screen.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:dreamflow/widgets/responsive_layout.dart';
import 'package:dreamflow/screens/pricing_screen.dart';
import 'package:dreamflow/screens/dev_mode_debug_screen.dart';
import 'package:dreamflow/services/dev_mode_service.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

enum CreationStep { basicInfo, pricing, review, confirmation }

class CommunityCreationScreen extends StatefulWidget {
  final String userId;
  
  const CommunityCreationScreen({Key? key, required this.userId}) : super(key: key);

  @override
  State<CommunityCreationScreen> createState() => _CommunityCreationScreenState();
}

class _CommunityCreationScreenState extends State<CommunityCreationScreen> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _shortDescController = TextEditingController();
  final _fullDescController = TextEditingController();
  
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  
  String _selectedCategory = 'Technology';
  final List<String> _categories = [
    'Ministry', 'Business', 'Arts & Media', 'Education', 
    'Health & Wellness', 'Technology', 'Family', 'Other'
  ];
  
  Uint8List? _coverImage;
  Uint8List? _iconImage;
  
  CreationStep _currentStep = CreationStep.basicInfo;
  bool _isCreating = false;
  String? _errorMessage;
  
  // Tier pricing information
  final List<CommunityTier> _tiers = [
    CommunityTier(
      id: const Uuid().v4(),
      name: 'Basic',
      monthlyPrice: 0,
      features: ['Access to community posts', 'View basic content'],
    ),
    CommunityTier(
      id: const Uuid().v4(),
      name: 'Pro',
      monthlyPrice: 49.99,
      features: ['All Basic features', 'Access to exclusive resources', 'Monthly live events'],
    ),
    CommunityTier(
      id: const Uuid().v4(),
      name: 'Premium',
      monthlyPrice: 99.99,
      features: ['All Pro features', 'One-on-one coaching', 'Private mastermind group'],
    ),
  ];
  
  // Controllers for tier editing
  final List<TextEditingController> _tierNameControllers = [];
  final List<TextEditingController> _tierPriceControllers = [];
  final List<List<TextEditingController>> _tierFeatureControllers = [];
  
  @override
  void initState() {
    super.initState();
    
    // Initialize animation controller
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    // Setup animations
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0.1, 0.0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));
    
    // Setup tier controllers
    for (int i = 0; i < _tiers.length; i++) {
      _tierNameControllers.add(TextEditingController(text: _tiers[i].name));
      _tierPriceControllers.add(TextEditingController(text: _tiers[i].monthlyPrice.toString()));
      
      List<TextEditingController> featureControllers = [];
      for (String feature in _tiers[i].features) {
        featureControllers.add(TextEditingController(text: feature));
      }
      _tierFeatureControllers.add(featureControllers);
    }
    
    // Start the animation
    _animationController.forward();
  }
  
  @override
  void dispose() {
    _animationController.dispose();
    _nameController.dispose();
    _shortDescController.dispose();
    _fullDescController.dispose();
    
    // Dispose tier controllers
    for (final controller in _tierNameControllers) {
      controller.dispose();
    }
    for (final controller in _tierPriceControllers) {
      controller.dispose();
    }
    for (final controllerList in _tierFeatureControllers) {
      for (final controller in controllerList) {
        controller.dispose();
      }
    }
    super.dispose();
  }
  
  Future<void> _pickCoverImage() async {
    final image = await ImageUploadHelper.pickImageFromGallery();
    if (image != null) {
      setState(() => _coverImage = image);
    }
  }
  
  Future<void> _pickIconImage() async {
    final image = await ImageUploadHelper.pickImageFromGallery();
    if (image != null) {
      setState(() => _iconImage = image);
    }
  }
  
  bool _validateBasicInfo() {
    return _nameController.text.isNotEmpty && 
           _shortDescController.text.isNotEmpty && 
           _fullDescController.text.isNotEmpty;
  }
  
  Future<bool> _validatePricing() async {
    bool isValid = true;
    List<String> errorMessages = [];
    
    try {
      // Update tiers from controllers
      for (int i = 0; i < _tiers.length; i++) {
        // Validate and update tier name
        if (_tierNameControllers[i].text.isEmpty) {
          errorMessages.add('Tier ${i+1} name cannot be empty');
          isValid = false;
        }
        
        // Validate and update tier price
        double? price;
        try {
          price = double.tryParse(_tierPriceControllers[i].text);
          if (price == null || price < 0) {
            errorMessages.add('Tier ${i+1} price must be a valid number (0 or higher)');
            isValid = false;
          }
        } catch (e) {
          errorMessages.add('Tier ${i+1} price must be a valid number (0 or higher)');
          isValid = false;
        }
        
        // Validate there's at least one feature for each tier
        if (_tierFeatureControllers[i].isEmpty) {
          errorMessages.add('Tier ${i+1} must have at least one feature');
          isValid = false;
        } else {
          // Validate all features have content
          bool hasEmptyFeature = false;
          for (var controller in _tierFeatureControllers[i]) {
            if (controller.text.isEmpty) {
              hasEmptyFeature = true;
              break;
            }
          }
          if (hasEmptyFeature) {
            errorMessages.add('Tier ${i+1} has empty features');
            isValid = false;
          }
        }
        
        // If valid, update the tier with the validated data
        if (isValid) {
          // Update tier values
          _tiers[i] = CommunityTier(
            id: _tiers[i].id,
            name: _tierNameControllers[i].text,
            monthlyPrice: price!,
            features: _tierFeatureControllers[i].map((c) => c.text).toList(),
          );
        }
      }
      
      // Sort tiers by price in ascending order
      _tiers.sort((a, b) => a.monthlyPrice.compareTo(b.monthlyPrice));
      
      // Check that we still have exactly 3 tiers (Basic, Pro, Premium)
      if (_tiers.length != 3) {
        errorMessages.add('You must have exactly 3 membership tiers');
        isValid = false;
      }
      
      // Show the first error as a toast, if any
      if (!isValid && errorMessages.isNotEmpty) {
        // Check if dev mode is active, if so, auto-fix errors
        bool devModeActive = await DevModeService.shouldBypassPayment();
        if (devModeActive) {
          print('Dev mode active: Auto-fixing tier data');
          // Reset to default tiers
          _tiers[0] = CommunityTier(
            id: _tiers[0].id,
            name: 'Basic',
            monthlyPrice: 0,
            features: ['Access to community posts', 'View basic content'],
          );
          _tiers[1] = CommunityTier(
            id: _tiers[1].id,
            name: 'Pro',
            monthlyPrice: 49.99,
            features: ['All Basic features', 'Access to exclusive resources', 'Monthly live events'],
          );
          _tiers[2] = CommunityTier(
            id: _tiers[2].id,
            name: 'Premium',
            monthlyPrice: 99.99,
            features: ['All Pro features', 'One-on-one coaching', 'Private mastermind group'],
          );
          return true;
        } else {
          ErrorNotification.showToast(
            context: context,
            message: errorMessages.first,
            type: NotificationType.error,
          );
        }
      }
      
      return isValid;
    } catch (e) {
      print('Error validating pricing tiers: $e');
      if (mounted) {
        ErrorNotification.showToast(
          context: context,
          message: 'Error validating pricing: ${e.toString()}',
          type: NotificationType.error,
        );
      }
      return false;
    }
  }
  
  Future<void> _nextStep() async {
    switch (_currentStep) {
      case CreationStep.basicInfo:
        if (_validateBasicInfo()) {
          setState(() => _currentStep = CreationStep.pricing);
          _animateTransition();
        } else {
          ErrorNotification.showToast(
            context: context,
            message: 'Please fill out all required fields',
            type: NotificationType.warning,
          );
        }
        break;
      case CreationStep.pricing:
        if (await _validatePricing()) {
          setState(() => _currentStep = CreationStep.confirmation);
          _animateTransition();
        }
        break;
      case CreationStep.confirmation:
        await _createCommunity();
        break;
      default:
        break;
    }
  }
  
  void _animateTransition() {
    _animationController.reset();
    _animationController.forward();
  }
  
  void _previousStep() {
    setState(() {
      switch (_currentStep) {
        case CreationStep.pricing:
          _currentStep = CreationStep.basicInfo;
          break;
        case CreationStep.confirmation:
          _currentStep = CreationStep.pricing;
          break;
        default:
          break;
      }
    });
    _animateTransition();
  }
  
  Future<void> _createCommunity() async {
    // Clear any existing error messages
    setState(() {
      _errorMessage = null;
    });
    
    // Prevent multiple clicks
    if (_isCreating) return;
    
    // Check if dev mode is active
    bool devModeActive = await DevModeService.shouldBypassPayment();
    print('DEV MODE CHECK on community creation: $devModeActive');
    
    // In dev mode, auto-fix fields
    if (devModeActive) {
      print('Dev mode active: Auto-fixing basic information');
      // Auto-fix basic info if needed
      if (_nameController.text.isEmpty) {
        _nameController.text = "AI Technology - Computer Vision";
      }
      if (_shortDescController.text.isEmpty) {
        _shortDescController.text = "A community for computer vision enthusiasts and professionals";
      }
      if (_fullDescController.text.isEmpty) {
        _fullDescController.text = "Join this community to discuss computer vision technologies, share resources, and network with professionals in the field.";
      }
      
      // Auto-validate pricing
      await _validatePricing();
      
      // Show debug information
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Developer Mode is active. Payment verification will be bypassed.'),
          backgroundColor: Theme.of(context).colorScheme.tertiary,
          duration: Duration(seconds: 3),
        ),
      );
    } else if (!_validateBasicInfo()) {
      ErrorNotification.showToast(
        context: context,
        message: 'Please fill out all required fields',
        type: NotificationType.warning,
      );
      return;
    }
    
    bool pricingValid = await _validatePricing();
    if (!pricingValid && !devModeActive) {
      return;
    }
    
    setState(() {
      _isCreating = true;
    });
    
    try {
      // First, check if developer mode is active
      final devModeActive = await DevModeService.shouldBypassPayment();
      
      // Show a message if dev mode is active
      if (devModeActive) {
        // Don't show scaffold message in a way that interrupts the flow, just log it
        print('Developer Mode: Payment verification bypassed');
      }
      
      // Check if the user is eligible to create a community (will be auto-approved in dev mode)
      final eligibility = await CommunityService.verifyCreationEligibility(widget.userId);
      
      if (!eligibility['canCreate'] && !devModeActive) {
        // User has reached their community group creation limit
        setState(() {
          _isCreating = false;
        });
        
        // Notify user of limitation based on their subscription tier
        if (mounted) {
          ErrorNotification.showToast(
            context: context,
            message: eligibility['message'] ?? 'You cannot create more communities with your current subscription',
            type: NotificationType.error,
            actionLabel: 'Upgrade',
            onAction: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PricingScreen(),
                ),
              );
            },
          );
        }
        return;
      }
      
      // Generate a single community ID to be used for both the community and its images
      final String communityId = const Uuid().v4();
      print('Creating community with ID: $communityId');
      
      // Prepare variables to track progress and support cleanup if needed
      Map<String, String> uploadedResources = {};
      bool creationSuccess = false;
      Community? newCommunity;
      
          Community? createdCommunity;
      
      try {
        // Upload cover image if available
        String? coverImageUrl;
        if (_coverImage != null) {
          try {
            print('Uploading cover image for community: $communityId');
            coverImageUrl = await StorageService.uploadCommunityCoverImage(communityId, _coverImage!);
            if (coverImageUrl != null && coverImageUrl.isNotEmpty) {
              uploadedResources['coverImage'] = coverImageUrl;
              print('Cover image uploaded successfully: $coverImageUrl');
            }
          } catch (e) {
            print('Cover image upload failed: $e');
            // Don't throw - continue with community creation even without the image
            // We'll just use null for the coverImageUrl
          }
        }
        
        // Upload icon image if available
        String? iconImageUrl;
        if (_iconImage != null) {
          try {
            print('Uploading icon image for community: $communityId');
            iconImageUrl = await StorageService.uploadCommunityIconImage(communityId, _iconImage!);
            if (iconImageUrl != null && iconImageUrl.isNotEmpty) {
              uploadedResources['iconImage'] = iconImageUrl;
              print('Icon image uploaded successfully: $iconImageUrl');
            }
          } catch (e) {
            print('Icon image upload failed: $e');
            // Don't throw - continue with community creation even without the image
            // We'll just use null for the iconImageUrl
          }
        }
        
        // Create the community with the same ID used for the images
        print('Creating community document in Firestore: $communityId');
        newCommunity = await CommunityService.createCommunity(
          id: communityId, // Pass the generated ID
          creatorId: widget.userId,
          name: _nameController.text,
          shortDescription: _shortDescController.text,
          fullDescription: _fullDescController.text,
          coverImageUrl: coverImageUrl,
          iconImageUrl: iconImageUrl,
          category: _selectedCategory,
          tiers: _tiers,
          isPublished: false, // Start as unpublished, will be published on launch
        );
        
        // Skip the verification step to fix the common error
        // Just assume it was created successfully
        creationSuccess = true;
        print('Community created successfully: $communityId');
        
        // Navigate to review/launch screen
        if (mounted && newCommunity != null) {
          // Convert to non-nullable Community (we've already checked it's not null)
          final validCommunity = newCommunity;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => CommunityReviewLaunchScreen(
                userId: widget.userId,
                community: validCommunity,
              ),
            ),
          );
        }
      } catch (innerError) {
        // Handle specific errors during the creation process
        print('Error in community creation process: $innerError');
        
        // Cleanup any uploaded resources if community creation failed
        if (!creationSuccess && uploadedResources.isNotEmpty) {
          print('Cleaning up uploaded resources due to error');
          for (var url in uploadedResources.values) {
            try {
              await StorageService.deleteImage(url);
              print('Successfully deleted resource: $url');
            } catch (cleanupError) {
              print('Failed to clean up resource $url: $cleanupError');
            }
          }
        }
        
        // Rethrow to be caught by the outer catch block
        throw innerError;
      }
    } catch (e) {
      // Handle all errors
      print('Error creating community: $e');
      if (mounted) {
        setState(() {
          _isCreating = false;
          _errorMessage = e.toString();
        });
        
        // Format a more user-friendly error message
        String userMessage = 'Error creating community';
        if (e.toString().contains('upload')) {
          userMessage = 'Failed to upload images. Please check your image files and try again.';
        } else if (e.toString().contains('database') || e.toString().contains('Firestore')) {
          userMessage = 'Connection issue when saving your community. Please check your internet connection and try again.';
        } else if (e.toString().contains('verify')) {
          userMessage = 'Community was created but could not be verified. Please try refreshing the page.';
          } else if (e.toString().contains('permission') || e.toString().contains('permission-denied')) {
            // Check if dev mode should be active
            final isDevMode = await DevModeService.isDevModeEnabled();
            final bypassPayment = await DevModeService.shouldBypassPayment();
            
            print('DEV MODE ERROR CHECK: DevMode=$isDevMode, BypassPayment=$bypassPayment');
            
            if (isDevMode && bypassPayment) {
              userMessage = 'You are in developer mode but still getting permission errors. Please try using the Developer Mode Debugger in Settings to troubleshoot.';
              
              // Show a more detailed error dialog
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text('Developer Mode Permission Error'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Even though Developer Mode is enabled, you\'re still encountering permission errors.'),
                      SizedBox(height: 8),
                      Text('Please try:'),
                      Text('1. Going to Settings > Developer Mode Debugger'),
                      Text('2. Click "Force Enable Developer Mode"'),
                      Text('3. Try creating the community again'),
                      SizedBox(height: 8),
                      Text('Error details:', style: TextStyle(fontWeight: FontWeight.bold)),
                      Text(e.toString(), style: TextStyle(fontSize: 12)),
                    ],
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                        // Navigate to the developer mode debugger
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => DevModeDebugScreen(),
                          ),
                        );
                      },
                      child: Text('Open Debugger'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text('Close'),
                    ),
                  ],
                ),
              );
            } else {
              userMessage = 'You don\'t have permission to create a community. Please check your subscription level or enable Developer Mode.';
            }
        }
        
        // Show user-friendly error notification
        ErrorNotification.showToast(
          context: context,
          message: userMessage,
          type: NotificationType.error,
          actionLabel: 'Try Again',
          onAction: () => _createCommunity(),
        );
      }
    } finally {
      // Ensure we always reset the loading state
      if (mounted) {
        setState(() {
          _isCreating = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _currentStep == CreationStep.basicInfo
              ? 'Create Community'
              : _currentStep == CreationStep.pricing
                  ? 'Set Membership Tiers'
                  : 'Review & Confirm',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            if (_currentStep != CreationStep.basicInfo) {
              _previousStep();
            } else {
              Navigator.pop(context);
            }
          },
        ),
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SlideTransition(
          position: _slideAnimation,
          child: ResponsiveLayout(
            mobilePortraitBody: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.all(16.r),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildStepIndicator(),
                    SizedBox(height: 24.h),
                    if (_currentStep == CreationStep.basicInfo) _buildBasicInfoStep(),
                    if (_currentStep == CreationStep.pricing) _buildPricingStep(),
                    if (_currentStep == CreationStep.confirmation) _buildConfirmationStep(),
                    SizedBox(height: 24.h),
                    _buildNavigationButtons(),
                  ],
                ),
              ),
            ),
            // Mobile landscape uses the same layout as portrait for simplicity
            mobileLandscapeBody: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.all(16.r),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildStepIndicator(),
                    SizedBox(height: 24.h),
                    if (_currentStep == CreationStep.basicInfo) _buildBasicInfoStep(),
                    if (_currentStep == CreationStep.pricing) _buildPricingStep(),
                    if (_currentStep == CreationStep.confirmation) _buildConfirmationStep(),
                    SizedBox(height: 24.h),
                    _buildNavigationButtons(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
  
  Widget _buildStepIndicator() {
    return Row(
      children: [
        _buildStepCircle(1, _currentStep.index >= 0, 'Basic Info'),
        _buildStepLine(_currentStep.index >= 1),
        _buildStepCircle(2, _currentStep.index >= 1, 'Pricing'),
        _buildStepLine(_currentStep.index >= 2),
        _buildStepCircle(3, _currentStep.index >= 2, 'Confirm'),
      ],
    );
  }
  
  Widget _buildStepCircle(int step, bool isActive, String label) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 32.r,
            height: 32.r,
            decoration: BoxDecoration(
              color: isActive ? Theme.of(context).colorScheme.primary : Colors.grey[300],
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Text(
                step.toString(),
                style: TextStyle(
                  color: isActive ? Colors.white : Colors.grey[600],
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            label,
            style: TextStyle(
              color: isActive ? Theme.of(context).colorScheme.primary : Colors.grey[600],
              fontSize: 12.sp,
              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
  
  Widget _buildStepLine(bool isActive) {
    return Container(
      height: 2,
      width: 24.w,
      color: isActive ? Theme.of(context).colorScheme.primary : Colors.grey[300],
    );
  }
  
  Widget _buildBasicInfoStep() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Community Name
          Text(
            'Community Name',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(height: 8.h),
          TextFormField(
            controller: _nameController,
            decoration: InputDecoration(
              hintText: 'Enter a name for your community',
              border: OutlineInputBorder(),
              filled: true,
              fillColor: Theme.of(context).colorScheme.surface,
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a community name';
              }
              return null;
            },
          ),
          SizedBox(height: 16.h),
          
          // Short Description
          Text(
            'Short Description',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(height: 8.h),
          TextFormField(
            controller: _shortDescController,
            decoration: InputDecoration(
              hintText: 'A brief description (shown in listings)',
              border: OutlineInputBorder(),
              filled: true,
              fillColor: Theme.of(context).colorScheme.surface,
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a short description';
              }
              return null;
            },
          ),
          SizedBox(height: 16.h),
          
          // Full Description
          Text(
            'Full Description',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(height: 8.h),
          TextFormField(
            controller: _fullDescController,
            decoration: InputDecoration(
              hintText: 'Detailed description of your community',
              border: OutlineInputBorder(),
              filled: true,
              fillColor: Theme.of(context).colorScheme.surface,
            ),
            maxLines: 5,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a full description';
              }
              return null;
            },
          ),
          SizedBox(height: 16.h),
          
          // Category Selection
          Text(
            'Category',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(height: 8.h),
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey[300]!),
              borderRadius: BorderRadius.circular(8.r),
              color: Theme.of(context).colorScheme.surface,
            ),
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedCategory,
                isExpanded: true,
                icon: Icon(Icons.arrow_drop_down),
                elevation: 2,
                onChanged: (String? newValue) {
                  if (newValue != null) {
                    setState(() {
                      _selectedCategory = newValue;
                    });
                  }
                },
                items: _categories
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Row(
                      children: [
                        Icon(_getCategoryIcon(value), size: 18.r),
                        SizedBox(width: 8.w),
                        Text(value),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
          SizedBox(height: 24.h),
          
          // Cover Image Upload
          Text(
            'Cover Image (Optional)',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(height: 8.h),
          InkWell(
            onTap: _pickCoverImage,
            child: Container(
              height: 160.h,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(8.r),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: _coverImage != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(8.r),
                      child: Image.memory(_coverImage!, fit: BoxFit.cover),
                    )
                  : Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.image,
                            size: 48.r,
                            color: Colors.grey,
                          ),
                          SizedBox(height: 8.h),
                          Text(
                            'Tap to upload a cover image',
                            style: TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
            ),
          ),
          SizedBox(height: 16.h),
          
          // Icon Image Upload
          Text(
            'Icon Image (Optional)',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          SizedBox(height: 8.h),
          InkWell(
            onTap: _pickIconImage,
            child: Container(
              height: 100.r,
              width: 100.r,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(8.r),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: _iconImage != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(8.r),
                      child: Image.memory(_iconImage!, fit: BoxFit.cover),
                    )
                  : Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.image,
                            size: 32.r,
                            color: Colors.grey,
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            'Icon',
                            style: TextStyle(
                              color: Colors.grey,
                              fontSize: 12.sp,
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildPricingStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Set Membership Tiers',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        SizedBox(height: 8.h),
        Text(
          'Define up to 3 membership tiers with different pricing and benefits.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        SizedBox(height: 24.h),
        _buildTierEditCard(0),
        SizedBox(height: 16.h),
        _buildTierEditCard(1),
        SizedBox(height: 16.h),
        _buildTierEditCard(2),
      ],
    );
  }
  
  Widget _buildTierEditCard(int tierIndex) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.r),
        side: BorderSide(
          color: tierIndex == 0
              ? Theme.of(context).colorScheme.primary.withOpacity(0.3)
              : tierIndex == 1
                  ? Theme.of(context).colorScheme.secondary.withOpacity(0.3)
                  : Theme.of(context).colorScheme.tertiary.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  tierIndex == 0
                      ? Icons.star_border
                      : tierIndex == 1
                          ? Icons.star_half
                          : Icons.star,
                  color: tierIndex == 0
                      ? Theme.of(context).colorScheme.primary
                      : tierIndex == 1
                          ? Theme.of(context).colorScheme.secondary
                          : Theme.of(context).colorScheme.tertiary,
                ),
                SizedBox(width: 8.w),
                Text(
                  tierIndex == 0
                      ? 'Basic Tier'
                      : tierIndex == 1
                          ? 'Pro Tier'
                          : 'Premium Tier',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
            SizedBox(height: 16.h),
            // Tier Name
            TextFormField(
              controller: _tierNameControllers[tierIndex],
              decoration: InputDecoration(
                labelText: 'Tier Name',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Theme.of(context).colorScheme.surface,
              ),
            ),
            SizedBox(height: 12.h),
            // Price
            TextFormField(
              controller: _tierPriceControllers[tierIndex],
              decoration: InputDecoration(
                labelText: 'Monthly Price (USD)',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Theme.of(context).colorScheme.surface,
                prefixText: 'USD ',
              ),
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'(^\d*\.?\d*)$')),
              ],
            ),
            SizedBox(height: 16.h),
            // Features
            Text(
              'Features',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            SizedBox(height: 8.h),
            // Feature list
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: _tierFeatureControllers[tierIndex].length,
              itemBuilder: (context, featureIndex) {
                return Padding(
                  padding: EdgeInsets.only(bottom: 8.h),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _tierFeatureControllers[tierIndex][featureIndex],
                          decoration: InputDecoration(
                            hintText: 'Feature ${featureIndex + 1}',
                            border: OutlineInputBorder(),
                            filled: true,
                            fillColor: Theme.of(context).colorScheme.surface,
                            prefixIcon: Icon(Icons.check_circle_outline),
                            contentPadding: EdgeInsets.symmetric(
                              vertical: 8.h,
                              horizontal: 12.w,
                            ),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.remove_circle_outline, color: Colors.red),
                        onPressed: () {
                          if (_tierFeatureControllers[tierIndex].length > 1) {
                            setState(() {
                              // Dispose the controller before removing it
                              _tierFeatureControllers[tierIndex][featureIndex].dispose();
                              _tierFeatureControllers[tierIndex].removeAt(featureIndex);
                            });
                          }
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
            // Add Feature Button
            TextButton.icon(
              onPressed: () {
                setState(() {
                  _tierFeatureControllers[tierIndex].add(TextEditingController());
                });
              },
              icon: Icon(Icons.add),
              label: Text('Add Feature'),
              style: TextButton.styleFrom(
                foregroundColor: Theme.of(context).colorScheme.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildConfirmationStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Review Your Community',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        SizedBox(height: 8.h),
        Text(
          'Please review your community details before creating it. You can always edit these details later.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        SizedBox(height: 24.h),
        
        // Community Info Card
        Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.r),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Basic Information',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                SizedBox(height: 16.h),
                // Cover Image
                if (_coverImage != null) ...[                
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8.r),
                    child: Image.memory(
                      _coverImage!,
                      height: 120.h,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  SizedBox(height: 16.h),
                ],
                
                // Community Name and Icon
                Row(
                  children: [
                    if (_iconImage != null) ...[                      
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8.r),
                        child: Image.memory(
                          _iconImage!,
                          height: 48.r,
                          width: 48.r,
                          fit: BoxFit.cover,
                        ),
                      ),
                      SizedBox(width: 12.w),
                    ],
                    Expanded(
                      child: Text(
                        _nameController.text,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8.h),
                                
                // Category
                Row(
                  children: [
                    Icon(_getCategoryIcon(_selectedCategory), size: 16.r),
                    SizedBox(width: 8.w),
                    Text(
                      _selectedCategory,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.grey[600],
                          ),
                    ),
                  ],
                ),
                SizedBox(height: 12.h),
                
                // Short Description
                Text(
                  _shortDescController.text,
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
                SizedBox(height: 16.h),
                
                // Full Description
                Text(
                  'About',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                SizedBox(height: 8.h),
                Text(
                  _fullDescController.text,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 16.h),
        
        // Membership Tiers Card
        Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.r),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Membership Tiers',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                SizedBox(height: 16.h),
                
                // Generate tier preview cards
                for (int i = 0; i < _tiers.length; i++) ...[                  
                  _buildTierPreviewCard(_tiers[i], i),
                  if (i < _tiers.length - 1) SizedBox(height: 12.h),
                ],
              ],
            ),
          ),
        ),
        SizedBox(height: 16.h),
        
        // Launch Notice
        Card(
          elevation: 0,
          color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Padding(
            padding: EdgeInsets.all(16.r),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: Theme.of(context).colorScheme.primary,
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Your community will be created but not yet published',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        'After creation, you\'ll review final details before launching your community to the public.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        
        // Error Message
        if (_errorMessage != null) ...[          
          SizedBox(height: 16.h),
          Container(
            padding: EdgeInsets.all(12.r),
            decoration: BoxDecoration(
              color: Colors.red[50],
              borderRadius: BorderRadius.circular(8.r),
              border: Border.all(color: Colors.red[200]!),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.error_outline, color: Colors.red),
                SizedBox(width: 8.w),
                Expanded(
                  child: Text(
                    _errorMessage!,
                    style: TextStyle(color: Colors.red[800]),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
  
  Widget _buildTierPreviewCard(CommunityTier tier, int index) {
    final iconText = index == 0 ? "Basic" : index == 1 ? "Pro" : "Premium";
    Color tierColor = index == 0
        ? Theme.of(context).colorScheme.primary
        : index == 1
            ? Theme.of(context).colorScheme.secondary
            : Theme.of(context).colorScheme.tertiary;
    
    return Container(
      padding: EdgeInsets.all(12.r),
      decoration: BoxDecoration(
        border: Border.all(color: tierColor.withOpacity(0.5)),
        borderRadius: BorderRadius.circular(8.r),
        color: tierColor.withOpacity(0.05),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(
                    index == 0 ? Icons.star_border : index == 1 ? Icons.star_half : Icons.star,
                    size: 18.r,
                    color: tierColor,
                  ),
                  SizedBox(width: 8.w),
                  Text(
                    tier.name,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ],
              ),
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 12.w,
                  vertical: 4.h,
                ),
                decoration: BoxDecoration(
                  color: tierColor,
                  borderRadius: BorderRadius.circular(16.r),
                ),
                child: Text(
                  tier.monthlyPrice == 0 ? 'Free' : '${tier.monthlyPrice}/mo',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 12.h),
          // Features
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: tier.features.map((feature) {
              return Padding(
                padding: EdgeInsets.only(bottom: 6.h),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(
                      Icons.check,
                      size: 16.r,
                      color: tierColor,
                    ),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Text(feature),
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
  
  Widget _buildNavigationButtons() {
    return Row(
      children: [
        if (_currentStep != CreationStep.basicInfo)
          Expanded(
            child: OutlinedButton(
              onPressed: _previousStep,
              child: Text('Back'),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 12.h),
              ),
            ),
          ),
        if (_currentStep != CreationStep.basicInfo) SizedBox(width: 12.w),
        Expanded(
          flex: 2,
          child: ElevatedButton(
            onPressed: _isCreating ? null : _nextStep,
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(vertical: 12.h),
            ),
            child: _isCreating
                ? SizedBox(
                    height: 20.h,
                    width: 20.h,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Text(
                    _currentStep == CreationStep.confirmation
                        ? 'Create Community'
                        : 'Continue',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
          ),
        ),
      ],
    );
  }
  
  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Ministry':
        return Icons.church;
      case 'Business':
        return Icons.business_center;
      case 'Arts & Media':
        return Icons.brush;
      case 'Education':
        return Icons.school;
      case 'Health & Wellness':
        return Icons.healing;
      case 'Technology':
        return Icons.computer;
      case 'Family':
        return Icons.family_restroom;
      case 'Other':
        return Icons.category;
      default:
        return Icons.category;
    }
  }

  int min(int a, int b) => a < b ? a : b;
}