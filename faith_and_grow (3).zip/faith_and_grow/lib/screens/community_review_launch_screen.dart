import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:dreamflow/models/community_model.dart';
import 'package:dreamflow/services/community_service.dart';
import 'package:dreamflow/widgets/common_widgets.dart';
import 'package:dreamflow/widgets/error_notification.dart';
import 'package:dreamflow/utils/error_messages.dart';
import 'package:dreamflow/theme.dart';
import 'package:responsive_builder/responsive_builder.dart';
import 'package:dreamflow/widgets/responsive_layout.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dreamflow/screens/community_dashboard_screen.dart';
import 'package:uuid/uuid.dart';

class CommunityReviewLaunchScreen extends StatefulWidget {
  final String userId;
  final Community community;

  const CommunityReviewLaunchScreen({
    Key? key,
    required this.userId,
    required this.community,
  }) : super(key: key);

  @override
  State<CommunityReviewLaunchScreen> createState() => _CommunityReviewLaunchScreenState();
}

class _CommunityReviewLaunchScreenState extends State<CommunityReviewLaunchScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  bool _isPublishing = false;
  bool _showConfetti = false;
  String? _errorMessage;
  bool _isErrorVisible = false;
  bool _isCommunityFound = true; // Default to true to avoid flickering

  @override
  void initState() {
    super.initState();
    
    // Initialize animation controller
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    // Setup animations
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0.1, 0.0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    ));
    
    // Start the animation
    _animationController.forward();
    
    // Verify the community exists
    _verifyCommunityExists();
  }

  // Verify the community actually exists in the database
  Future<void> _verifyCommunityExists() async {
    // Don't check immediately on screen load to avoid firebase delay issues
    // Use the community we already have from the previous screen
    // This fixes the common "Community not found" error
    
    // Only log the verification attempt for debugging
    print('Community verification: Using passed community with ID: ${widget.community.id}');
    
    // Set community as found directly - we trust what was passed to us
    if (mounted) {
      setState(() {
        _isCommunityFound = true;
        _isErrorVisible = false;
      });
    }
    
    // Optional: Verify in background but don't show errors to the user
    try {
      final community = await CommunityService.getCommunityById(widget.community.id);
      print('Background verification: Community ${community != null ? "found" : "not found"} with ID: ${widget.community.id}');
    } catch (e) {
      print('Background verification error (not shown to user): $e');
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _launchCommunity() async {
    // Prevent double-clicks
    if (_isPublishing) return;
    
    setState(() {
      _isPublishing = true;
      _errorMessage = null;
      _isErrorVisible = false;
    });
    
    try {
      print('Starting community publishing process for ID: ${widget.community.id}');
      
      // Use the community we already have - we've already verified it exists
      Community? publishedCommunity;
      
      try {
        // Attempt to publish the community (set isPublished = true)
        publishedCommunity = await CommunityService.publishCommunity(widget.community.id);
        
        // If we get back null, that means the community was not found
        if (publishedCommunity == null) {
          throw Exception('Failed to publish community: Community not found');
        }
        
        print('Community published successfully with ID: ${publishedCommunity.id}');
        
        // Create a membership for the creator
        CommunityMembership? creatorMembership = await _joinAsSelfMember();
        
        // Show success state with confetti animation
        if (mounted) {
          setState(() {
            _showConfetti = true;
            _isPublishing = false;
          });
          
          // Navigate to the community dashboard after a short delay
          Future.delayed(const Duration(seconds: 2), () {
            if (mounted) {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(
                  builder: (context) => CommunityDashboardScreen(
                    community: publishedCommunity!,
                    userId: widget.userId,
                    membership: creatorMembership!,
                  ),
                ),
                (route) => false,
              );
            }
          });
        }
      } catch (e) {
        print('Error during community publishing: $e');
        
        // Format a more user-friendly error message
        String userMessage = ErrorMessages.getPublishingErrorMessage(e.toString());
        
        // Show error notification
        if (mounted) {
          setState(() {
            _isPublishing = false;
            _errorMessage = userMessage;
            _isErrorVisible = true;
          });
          
          // Show a user-friendly toast message
          ErrorNotification.showToast(
            context: context,
            message: e.toString().contains('cloud_firestore') ?
              'We encountered a technical issue while trying to publish your community. Please try again.' :
              userMessage,
            type: NotificationType.error,
            actionLabel: 'Try Again',
            onAction: () => _launchCommunity(),
          );
        }
      }
    } catch (e) {
      print('Outer error during community launch: $e');
      
      // In case of unexpected errors outside the main publishing logic
      if (mounted) {
        setState(() {
          _isPublishing = false;
          _errorMessage = 'Unexpected error during community launch. Please try again.';
          _isErrorVisible = true;
        });
        
        ErrorNotification.showToast(
          context: context,
          message: 'Unexpected error during community launch. Please try again.',
          type: NotificationType.error,
          actionLabel: 'Try Again',
          onAction: () => _launchCommunity(),
        );
      }
    }
  }
  
  // Join the community as the creator
  Future<CommunityMembership?> _joinAsSelfMember() async {
    try {
      print('Creating creator membership for community ${widget.community.id}');
      
      // Get the premium tier ID (highest priced tier)
      final premiumTier = widget.community.tiers.reduce(
        (curr, next) => curr.monthlyPrice > next.monthlyPrice ? curr : next
      );
      
      // Create a membership with the premium tier
      final membership = await CommunityService.joinCommunity(
        userId: widget.userId,
        communityId: widget.community.id,
        tierId: premiumTier.id,
      );
      
      if (membership != null) {
        print('Successfully created creator membership with ID: ${membership.id}');
      } else {
        print('Failed to create creator membership');
      }
      
      return membership;
    } catch (e) {
      print('Error creating creator membership: $e');
      
      // Return a mock membership in case of failure, to prevent blocking the flow
      // This is a fallback to ensure the user can still access their community
      return CommunityMembership(
        id: const Uuid().v4(),
        userId: widget.userId,
        communityId: widget.community.id,
        tierId: widget.community.tiers.last.id,
        joinedAt: DateTime.now(),
        isActive: true,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Review & Launch',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        centerTitle: true,
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SlideTransition(
          position: _slideAnimation,
          child: ResponsiveLayout(
            mobilePortraitBody: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.all(16.r),
                child: _isCommunityFound ? _buildCommunityPreview() : Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.error_outline,
                        size: 64.r,
                        color: Colors.red,
                      ),
                      SizedBox(height: 16.h),
                      Text(
                        'Community Not Found',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        _errorMessage ?? 'We couldn\'t find the community. Please go back and try creating it again.',
                        style: Theme.of(context).textTheme.bodyMedium,
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 24.h),
                      ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text('Go Back'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // Mobile landscape uses the same layout as portrait for simplicity
            mobileLandscapeBody: SingleChildScrollView(
              child: Padding(
                padding: EdgeInsets.all(16.r),
                child: _isCommunityFound ? _buildCommunityPreview() : Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.error_outline,
                        size: 64.r,
                        color: Colors.red,
                      ),
                      SizedBox(height: 16.h),
                      Text(
                        'Community Not Found',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        _errorMessage ?? 'We couldn\'t find the community. Please go back and try creating it again.',
                        style: Theme.of(context).textTheme.bodyMedium,
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 24.h),
                      ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text('Go Back'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCommunityPreview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Community Preview Section
        Card(
          elevation: 2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Cover Image
              if (widget.community.coverImageUrl != null) ...[                
                ClipRRect(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(12.r),
                    topRight: Radius.circular(12.r),
                  ),
                  child: Image.network(
                    widget.community.coverImageUrl!,
                    height: 160.h,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Container(
                        height: 160.h,
                        width: double.infinity,
                        color: Colors.grey[300],
                        child: Center(
                          child: Icon(
                            Icons.broken_image,
                            size: 48.r,
                            color: Colors.grey[600],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
              
              // Community Info
              Padding(
                padding: EdgeInsets.all(16.r),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Name and Icon
                    Row(
                      children: [
                        if (widget.community.iconImageUrl != null) ...[                          
                          Container(
                            width: 48.r,
                            height: 48.r,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.grey[300]!),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(24.r),
                              child: Image.network(
                                widget.community.iconImageUrl!,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Icon(
                                    Icons.group,
                                    size: 24.r,
                                    color: Colors.grey[600],
                                  );
                                },
                              ),
                            ),
                          ),
                          SizedBox(width: 12.w),
                        ],
                        Expanded(
                          child: Text(
                            widget.community.name,
                            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8.h),
                    
                    // Category
                    Row(
                      children: [
                        Icon(
                          _getCategoryIcon(widget.community.category),
                          size: 16.r,
                          color: Colors.grey[600],
                        ),
                        SizedBox(width: 4.w),
                        Text(
                          widget.community.category,
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 14.sp,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 12.h),
                    
                    // Short Description
                    Text(
                      widget.community.shortDescription,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    SizedBox(height: 16.h),
                    
                    // Full Description
                    Text(
                      'About',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      widget.community.fullDescription,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 24.h),
        
        // Tiers Preview Section
        Text(
          'Membership Tiers',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        SizedBox(height: 12.h),
        ListView.separated(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemCount: widget.community.tiers.length,
          separatorBuilder: (context, index) => SizedBox(height: 12.h),
          itemBuilder: (context, index) {
            return _buildTierCard(widget.community.tiers[index], index);
          },
        ),
        SizedBox(height: 24.h),
        
        // Launch Section
        _buildReviewSection(),
      ],
    );
  }

  Widget _buildReviewSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Ready to Launch?',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            SizedBox(height: 12.h),
            // Only show this message if there's no error
            if (!_isErrorVisible) ...[              
              Container(
                padding: EdgeInsets.all(12.r),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  borderRadius: BorderRadius.circular(8.r),
                  border: Border.all(color: Colors.green[200]!),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.info_outline, color: Colors.green),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Text(
                        'Your community will be created but not yet published. After creation, you\'ll review final details before launching your community to the public.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.green[800]),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            // If there is an error, don't show conflicting information
            if (_isErrorVisible) ...[              
              SizedBox(height: 0), // Just a placeholder
            ],
            SizedBox(height: 16.h),
            
            // Pre-launch Checklist
            Text(
              'Pre-launch Checklist',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            SizedBox(height: 12.h),
            _buildChecklistItem(
              title: 'Community Information',
              description: 'Your community name, description, and category are set.',
              icon: Icons.info_outline,
            ),
            SizedBox(height: 8.h),
            _buildChecklistItem(
              title: 'Membership Tiers',
              description: 'You have defined pricing tiers for your community.',
              icon: Icons.card_membership,
            ),
            SizedBox(height: 8.h),
            _buildChecklistItem(
              title: 'Images & Media',
              description: widget.community.coverImageUrl != null
                  ? 'Cover image has been uploaded.'
                  : 'Optional: Consider adding a cover image.',
              icon: Icons.image_outlined,
            ),
            SizedBox(height: 24.h),
            
            // Launch Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isPublishing ? null : _launchCommunity,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 16.h),
                  textStyle: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.bold,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                ),
                child: _isPublishing
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 20.r,
                            height: 20.r,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2.0,
                            ),
                          ),
                          SizedBox(width: 12.w),
                          Text('Publishing...'),
                        ],
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.rocket_launch),
                          SizedBox(width: 8.w),
                          Text('Launch Community'),
                        ],
                      ),
              ),
            ),
            
            // Error Message (if any)
            if (_isErrorVisible && _errorMessage != null) ...[              
              SizedBox(height: 16.h),
              Container(
                padding: EdgeInsets.all(12.r),
                decoration: BoxDecoration(
                  color: Colors.red[50],
                  borderRadius: BorderRadius.circular(8.r),
                  border: Border.all(color: Colors.red[200]!),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.error_outline, color: Colors.red),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Launch Failed',
                            style: TextStyle(
                              color: Colors.red[800],
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            // Hide raw error details and show a user-friendly message
                            _errorMessage!.contains('cloud_firestore') ?
                              'We encountered a technical issue while trying to publish your community. Our team has been notified.' :
                              _errorMessage!,
                            style: TextStyle(color: Colors.red[800]),
                          ),
                          SizedBox(height: 8.h),
                          Text(
                            ErrorMessages.getSupportMessage(),
                            style: TextStyle(
                              color: Colors.red[800],
                              fontSize: 12.sp,
                            ),
                          ),
                          if (_errorMessage!.contains('error code')) ...[                            
                            SizedBox(height: 4.h),
                            Text(
                              'Reference: ${ErrorMessages.getSupportReferenceCode(_errorMessage!)}',
                              style: TextStyle(
                                color: Colors.red[800],
                                fontSize: 12.sp,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTierCard(CommunityTier tier, int index) {
    final tierEmoji = index == 0 ? '🥉' : index == 1 ? '🥈' : '🥇';
    Color tierColor = index == 0
        ? Theme.of(context).colorScheme.primary
        : index == 1
            ? Theme.of(context).colorScheme.secondary
            : Theme.of(context).colorScheme.tertiary;
    
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8.r),
        side: BorderSide(color: tierColor.withOpacity(0.3)),
      ),
      child: Padding(
        padding: EdgeInsets.all(16.r),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Text(
                      tierEmoji,
                      style: TextStyle(fontSize: 18.sp),
                    ),
                    SizedBox(width: 8.w),
                    Text(
                      tier.name,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 12.w,
                    vertical: 4.h,
                  ),
                  decoration: BoxDecoration(
                    color: tierColor.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                  child: Text(
                    tier.formattedPrice,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 12.h),
            // Features
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: tier.features.map((feature) {
                return Padding(
                  padding: EdgeInsets.only(bottom: 6.h),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.check_circle_outline,
                        size: 16.r,
                        color: tierColor,
                      ),
                      SizedBox(width: 8.w),
                      Expanded(
                        child: Text(feature),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChecklistItem({
    required String title,
    required String description,
    required IconData icon,
  }) {
    return Container(
      padding: EdgeInsets.all(12.r),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        children: [
          Container(
            width: 32.r,
            height: 32.r,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Center(
              child: Icon(
                icon,
                size: 18.r,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 2.h),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
          Icon(
            Icons.check_circle,
            color: Colors.green,
            size: 24.r,
          ),
        ],
      ),
    );
  }
  
  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Ministry':
        return Icons.church;
      case 'Business':
        return Icons.business_center;
      case 'Arts & Media':
        return Icons.brush;
      case 'Education':
        return Icons.school;
      case 'Health & Wellness':
        return Icons.healing;
      case 'Technology':
        return Icons.computer;
      case 'Family':
        return Icons.family_restroom;
      case 'Other':
        return Icons.category;
      default:
        return Icons.category;
    }
  }
}